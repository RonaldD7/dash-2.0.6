package com.dm.material.dashboard.candybar.adapters;

import android.support.annotation.NonNull;
import android.support.v4.util.SparseArrayCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.dm.material.dashboard.candybar.R;
import com.dm.material.dashboard.candybar.items.FAQs;

import java.util.Locale;


/*
 * CandyBar - Material Dashboard
 *
 * Copyright (c) 2014-2016 Dani Mahardhika
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

public class FAQsAdapter extends RecyclerView.Adapter<FAQsAdapter.ViewHolder> {

    private SparseArrayCompat<FAQs> mFAQs;
    private final SparseArrayCompat<FAQs> mFAQsAll;

    public FAQsAdapter(@NonNull SparseArrayCompat<FAQs> faqs) {
        mFAQs = faqs;
        mFAQsAll = mFAQs.clone();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(
                R.layout.fragment_faqs_item_list, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        holder.question.setText(mFAQs.get(position).getQuestion());
        holder.answer.setText(mFAQs.get(position).getAnswer());
    }

    @Override
    public int getItemCount() {
        return mFAQs.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        final TextView question;
        final TextView answer;

        ViewHolder(View itemView) {
            super(itemView);
            question = (TextView) itemView.findViewById(R.id.question);
            answer = (TextView) itemView.findViewById(R.id.answer);
        }
    }

    public void search(String query) {
        query = query.toLowerCase(Locale.getDefault());
        mFAQs.clear();
        if (query.length() == 0) mFAQs = mFAQsAll.clone();
        else {
            for (int i = 0; i < mFAQsAll.size(); i++) {
                FAQs faq = mFAQsAll.get(i);
                String question = faq.getQuestion().toLowerCase(Locale.getDefault());
                String answer = faq.getAnswer().toLowerCase(Locale.getDefault());
                if (question.contains(query) || answer.contains(query)) {
                    mFAQs.append(mFAQs.size(), faq);
                }
            }
        }
        notifyDataSetChanged();
    }

}
